# LifeLink FastAPI on Render Free

This guide deploys the API publicly while Supabase hosts PostgreSQL:

```text
Android app → Render Free FastAPI → Supabase Free PostgreSQL
```

## Prepare the repository

Push the contents of the `LifeLink-Cloud` package to a GitHub repository. The repository should contain these paths:

```text
lifelink_fastapi/
  Dockerfile
  render.yaml
  requirements.txt
  app/
  sql/
```

## Create the Render service

1. Open [Render](https://render.com/) and select **New → Web Service**.
2. Connect the GitHub repository.
3. Set **Root Directory** to `lifelink_fastapi`.
4. Set the runtime to **Docker**. Render should detect `Dockerfile` automatically.
5. Select the **Free** instance type.
6. Set the health check path to `/health` if Render does not detect it.
7. Add these environment variables:

```text
LIFELINK_DATABASE_URL=postgresql://USER:PASSWORD@HOST:5432/postgres?sslmode=require
LIFELINK_AUTH_REQUIRED=true
DB_POOL_SIZE=3
DB_MAX_OVERFLOW=5
FIREBASE_SERVICE_ACCOUNT_JSON=<paste the Firebase service-account JSON>
LIFELINK_REQUEST_SWEEP_SECONDS=300
LIFELINK_REQUEST_SWEEP_LIMIT=500
```

`LIFELINK_REQUEST_SWEEP_SECONDS` (default `300`) and `LIFELINK_REQUEST_SWEEP_LIMIT`
(default `500`) tune the background request-expiry sweeper. The limit caps how many
timed-out requests one tick transitions, so a large backlog is drained across ticks
instead of holding one long transaction; it is clamped to `1..5000` and a
non-integer value falls back to the default.

`FIREBASE_SERVICE_ACCOUNT_JSON` is **required for push notifications to work**. It
is declared in `render.yaml` with `sync: false`, which means Render prompts for
the value instead of reading it from the repository. Without it, `app/fcm.py`
reports FCM as disabled and a contacted donor is never notified — the contact is
recorded but no push is sent. Get the value from the Firebase console
(**Project settings → Service accounts → Generate new private key**), paste the
whole JSON document as the variable value, and redeploy. `.gitignore` deliberately
does not let this secret reach the repository.

> **Updating an existing Blueprint:** Render only prompts for `sync: false`
> values during the *initial* Blueprint creation. When you update an existing
> Blueprint, newly added `sync: false` variables are ignored, so add
> `FIREBASE_SERVICE_ACCOUNT_JSON` manually in the Render dashboard
> (**Environment → Add Environment Variable**) and redeploy. Until it is set,
> `app/fcm.py` reports FCM as disabled and push sending returns without sending.

`LIFELINK_REQUIRE_VERIFIED_DONORS` is optional and defaults to `false`: self-registered donors are matched to requests, and verified donors rank higher. Set it to `true` to match **only** donors whose `verified` flag was set by an administrator (the app has no verification workflow yet, so with `true` a new donor receives nothing until you set `donors.verified = true` in Supabase).

8. Deploy the service.
9. Test the generated URL:

```bash
curl https://YOUR-RENDER-SERVICE.onrender.com/health
```

Expected response:

```json
{"status":"ok","service":"lifelink-matching-postgres"}
```

## Configure Android

Set the Android app’s API base URL to:

```text
https://YOUR-RENDER-SERVICE.onrender.com/
```

Do not use the Supabase URL in the Android app. Supabase is the database; Render is the API host.

## Free-tier behavior

Render Free services sleep after 15 minutes without inbound traffic and may take approximately one minute to wake. They have monthly free instance-hour and bandwidth limits. They can be restarted or suspended, so this option is suitable for an MVP and testing rather than guaranteed production uptime.

Do not store application data on Render’s local filesystem. It is ephemeral. LifeLink data belongs in Supabase PostgreSQL.

## Security checklist

- Keep `LIFELINK_DATABASE_URL` only in Render environment variables.
- Never commit the real database password.
- Keep `LIFELINK_AUTH_REQUIRED=true` for the public service.
- Replace the current development bearer-token seam with verified JWT/Firebase/Supabase Auth before real-world deployment.
- Use HTTPS only in the Android app configuration.
