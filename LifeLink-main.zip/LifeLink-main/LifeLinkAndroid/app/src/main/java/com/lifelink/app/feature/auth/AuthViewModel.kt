package com.lifelink.app.feature.auth

import android.net.Uri

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.lifelink.app.core.auth.AuthResult
import com.lifelink.app.core.auth.AuthSession
import com.lifelink.app.core.auth.AuthCallbackKind
import com.lifelink.app.core.auth.SupabaseAuthRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface AuthState {
    data object Loading : AuthState
    data object SignedOut : AuthState
    data object SessionExpired : AuthState
    data class SignedIn(val session: AuthSession) : AuthState
    data object EmailConfirmationRequired : AuthState
    data class PasswordResetReady(val email: String?, val accessToken: String) : AuthState
    data object PasswordResetComplete : AuthState
    data class Message(val text: String, val isError: Boolean = false) : AuthState
    data class Error(val message: String) : AuthState
}

class AuthViewModel(private val repository: SupabaseAuthRepository) : ViewModel() {
    private val _state = MutableStateFlow<AuthState>(AuthState.Loading)
    val state: StateFlow<AuthState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            repository.session.collect { session ->
                if (session != null) _state.value = AuthState.SignedIn(session)
                else if (_state.value !is AuthState.EmailConfirmationRequired && _state.value !is AuthState.PasswordResetReady && _state.value !is AuthState.PasswordResetComplete) _state.value = AuthState.SignedOut
            }
        }
        viewModelScope.launch {
            repository.sessionExpired.collect { expired ->
                if (expired) _state.value = AuthState.SessionExpired
            }
        }
    }

    fun signIn(email: String, password: String) = authenticate { repository.signIn(email, password) }
    fun signUp(email: String, password: String) = authenticate { repository.signUp(email, password) }
    fun signOut() = repository.signOut()
    fun requestPasswordReset(email: String) = runNeutralRecovery { repository.requestPasswordReset(email) }
    fun resendConfirmation(email: String) = runRecovery(email) { repository.resendConfirmation(email) }
    fun handleAuthCallback(uri: Uri?) {
        if (uri == null) return
        repository.parseAuthCallback(uri)
            .onSuccess { callback ->
                if (callback.kind == AuthCallbackKind.RECOVERY) {
                    _state.value = AuthState.PasswordResetReady(callback.email, callback.accessToken)
                } else {
                    viewModelScope.launch {
                        _state.value = AuthState.Loading
                        repository.completeEmailConfirmation(callback)
                            .onSuccess { session -> _state.value = AuthState.SignedIn(session) }
                            .onFailure { _state.value = AuthState.Message(it.message ?: "Account confirmation could not be completed. Please sign in.", true) }
                    }
                }
            }
            .onFailure { _state.value = AuthState.Message(it.message ?: "Authentication link could not be confirmed.", true) }
    }
    fun updatePassword(accessToken: String, password: String) {
        viewModelScope.launch {
            _state.value = AuthState.Loading
            repository.updatePassword(accessToken, password)
                .onSuccess { _state.value = AuthState.PasswordResetComplete }
                .onFailure { _state.value = AuthState.Message(it.message ?: "Password could not be updated.", true) }
        }
    }

    private fun runRecovery(email: String, action: suspend () -> Result<Unit>) {
        viewModelScope.launch {
            _state.value = AuthState.Loading
            action().onSuccess { _state.value = AuthState.Message("Check your inbox for the next step.") }
                .onFailure { _state.value = AuthState.Message(it.message ?: "Authentication email could not be sent.", true) }
        }
    }

    /**
     * Password recovery must not reveal whether an email is registered. The same
     * neutral confirmation is shown whether or not the address exists, so the
     * flow cannot be used to enumerate accounts. A genuine failure still surfaces
     * a generic retry message that says nothing about the account.
     */
    private fun runNeutralRecovery(action: suspend () -> Result<Unit>) {
        viewModelScope.launch {
            _state.value = AuthState.Loading
            action()
            _state.value = AuthState.Message(
                "If that email has a LifeLink account, check your inbox for a reset link. If none arrives, try again later."
            )
        }
    }

    private fun authenticate(action: suspend () -> Result<AuthResult>) {
        viewModelScope.launch {
            _state.value = AuthState.Loading
            action().onSuccess { result ->
                _state.value = when (result) {
                    is AuthResult.SignedIn -> AuthState.SignedIn(result.session)
                    AuthResult.EmailConfirmationRequired -> AuthState.EmailConfirmationRequired
                }
            }.onFailure { _state.value = AuthState.Error(it.message ?: "Authentication failed") }
        }
    }
}

class AuthViewModelFactory(private val repository: SupabaseAuthRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = AuthViewModel(repository) as T
}
