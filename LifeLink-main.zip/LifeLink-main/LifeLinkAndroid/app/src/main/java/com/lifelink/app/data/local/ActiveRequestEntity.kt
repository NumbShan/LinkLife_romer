package com.lifelink.app.data.local

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.lifelink.app.domain.ActiveRequestSnapshot
import com.lifelink.app.domain.ActiveRequestStatus
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "active_requests")
data class ActiveRequestEntity(
    @androidx.room.PrimaryKey val requestId: String,
    val ownerId: String,
    val status: String,
    val notificationsCreated: Int,
    val matchesResponded: Int,
    val reason: String?,
    val lastUpdatedEpochMillis: Long
)

@Dao
interface ActiveRequestDao {
    @Query("SELECT * FROM active_requests WHERE ownerId = :ownerId ORDER BY lastUpdatedEpochMillis DESC LIMIT 1")
    fun observeLatest(ownerId: String): Flow<ActiveRequestEntity?>

    @Query("SELECT * FROM active_requests WHERE ownerId = :ownerId ORDER BY lastUpdatedEpochMillis DESC")
    fun observeAll(ownerId: String): Flow<List<ActiveRequestEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(request: ActiveRequestEntity)

    @Query("DELETE FROM active_requests WHERE ownerId = :ownerId AND requestId = :requestId")
    suspend fun delete(ownerId: String, requestId: String)

    @Query("DELETE FROM active_requests WHERE ownerId = :ownerId")
    suspend fun clearAll(ownerId: String)
}

fun ActiveRequestEntity.toDomain(): ActiveRequestSnapshot = ActiveRequestSnapshot(
    requestId = requestId,
    status = runCatching { ActiveRequestStatus.valueOf(status) }.getOrDefault(ActiveRequestStatus.MATCHING),
    notificationsCreated = notificationsCreated,
    matchesResponded = matchesResponded,
    reason = reason,
    lastUpdatedEpochMillis = lastUpdatedEpochMillis
)

fun ActiveRequestSnapshot.toEntity(ownerId: String): ActiveRequestEntity = ActiveRequestEntity(
    requestId = requestId,
    ownerId = ownerId,
    status = status.name,
    notificationsCreated = notificationsCreated,
    matchesResponded = matchesResponded,
    reason = reason,
    lastUpdatedEpochMillis = lastUpdatedEpochMillis
)
