package com.lifelink.app.data.repository

import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.google.gson.Gson
import com.lifelink.app.data.local.ActiveRequestDao
import com.lifelink.app.data.local.EmergencyRequestDraftDao
import com.lifelink.app.data.local.EmergencyRequestDraftEntity
import com.lifelink.app.data.local.PendingSubmissionDao
import com.lifelink.app.data.local.PendingSubmissionEntity
import com.lifelink.app.data.local.PendingSubmissionWorker
import com.lifelink.app.data.local.toDomain
import com.lifelink.app.data.local.toEntity
import com.lifelink.app.data.remote.ContactModerationRequest
import com.lifelink.app.data.remote.ContactSelectedDonorsRequest
import com.lifelink.app.data.remote.ContactSelectedDonorsResponse
import com.lifelink.app.data.remote.ContactStatusUpdateRequest
import com.lifelink.app.data.remote.DonorMatchResponse
import com.lifelink.app.data.remote.EmergencyRequestRequest
import com.lifelink.app.data.remote.LifeLinkApi
import com.lifelink.app.domain.ActiveRequestSnapshot
import com.lifelink.app.domain.ActiveRequestStatus
import com.lifelink.app.domain.ContactMethod
import com.lifelink.app.domain.DiscoveredDonor
import com.lifelink.app.domain.DonorProfileRepository
import com.lifelink.app.domain.DonorRepository
import com.lifelink.app.domain.EmergencyRequestDraft
import com.lifelink.app.domain.EmergencyRequestRepository
import com.lifelink.app.domain.Facility
import com.lifelink.app.domain.PrivacyRepository
import com.lifelink.app.domain.RequestHistoryItem
import com.lifelink.app.domain.RequesterContact
import com.lifelink.app.domain.SubmitResult
import com.lifelink.app.domain.Urgency
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.IOException

class EmergencyRequestRepositoryImpl(
    private val draftDao: EmergencyRequestDraftDao,
    private val pendingSubmissionDao: PendingSubmissionDao,
    private val activeRequestDao: ActiveRequestDao,
    private val api: LifeLinkApi,
    private val workManager: WorkManager,
    private val requesterIdProvider: () -> String? = { null },
    private val networkAvailable: () -> Boolean = { true },
) : EmergencyRequestRepository {
    override suspend fun saveDraft(draft: EmergencyRequestDraft) = draftDao.upsert(draft.toEntity(requireRequesterId()))

    override suspend fun loadDraft(id: String): EmergencyRequestDraft? = draftDao.findById(requireRequesterId(), id)?.toDomain()

    override fun observeActiveRequest(): Flow<ActiveRequestSnapshot?> =
        activeRequestDao.observeLatest(requireRequesterId()).map { it?.toDomain() }

    override fun observeRequestHistory(): Flow<List<ActiveRequestSnapshot>> =
        activeRequestDao.observeAll(requireRequesterId()).map { requests -> requests.map { it.toDomain() } }

    override suspend fun refreshRequestHistory(): List<RequestHistoryItem> = withContext(Dispatchers.IO) {
        val refreshStarted = System.currentTimeMillis()
        val ownerId = requireRequesterId()
        val response = api.requestHistory()
        if (!response.isSuccessful) throw IOException("Request history could not be loaded (${response.code()}).")
        val history = (response.body() ?: throw IOException("Request history returned an empty response.")).map { item ->
            RequestHistoryItem(
                requestId = item.requestId,
                status = runCatching { ActiveRequestStatus.valueOf(item.status.uppercase()) }.getOrDefault(ActiveRequestStatus.MATCHING),
                createdAt = item.createdAt,
                expiresAt = item.expiresAt,
                bloodType = item.bloodType,
                units = item.units,
                urgency = item.urgency,
                facilityName = item.facilityName,
                area = item.area,
                notificationsCreated = item.notificationsCreated,
                matchesResponded = item.matchesResponded,
                contactStatuses = item.contactStatuses,
            )
        }
        // Logout clears local account data. Restore a submitted request from this
        // account's server history so Home and status polling can resume.
        if (activeRequestDao.observeLatest(ownerId).first() == null) {
            val request = history.firstOrNull {
                it.status !in setOf(ActiveRequestStatus.FULFILLED, ActiveRequestStatus.EXPIRED, ActiveRequestStatus.CANCELLED)
            } ?: history.firstOrNull()
            request?.let {
                activeRequestDao.upsert(
                    ActiveRequestSnapshot(
                        requestId = it.requestId,
                        status = it.status,
                        notificationsCreated = it.notificationsCreated,
                        matchesResponded = it.matchesResponded,
                        // A request submitted during this fetch remains the latest.
                        lastUpdatedEpochMillis = refreshStarted,
                    ).toEntity(ownerId),
                )
            }
        }
        history
    }

    override suspend fun refreshActiveRequest(requestId: String): ActiveRequestSnapshot? = withContext(Dispatchers.IO) {
        try {
            val response = api.getEmergencyRequest(requestId)
            if (!response.isSuccessful) return@withContext null
            val body = response.body() ?: return@withContext null
            val snapshot = body.toSnapshot()
            activeRequestDao.upsert(snapshot.toEntity(requireRequesterId()))
            snapshot
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            null
        }
    }

    override suspend fun submit(draft: EmergencyRequestDraft): SubmitResult = withContext(Dispatchers.IO) {
        try {
            val response = api.submitEmergencyRequest(draft.id, EmergencyRequestRequest.from(draft, requesterIdProvider()))
            if (!response.isSuccessful) {
                SubmitResult.Error(
                    serverError(response.code(), response.errorBody()?.string()),
                    retryable =
                    response.code() == 408 || response.code() == 429 || response.code() >= 500,
                )
            } else {
                val body = response.body()
                if (body == null) {
                    SubmitResult.Error("The server returned an empty response. Your draft is still saved.")
                } else if (body.status.equals("manual_broadcast", ignoreCase = true)) {
                    val fallback = SubmitResult.ManualFallback(
                        body.requestId,
                        body.reason ?: "Automatic matching is unavailable for this request.",
                    )
                    activeRequestDao.upsert(
                        ActiveRequestSnapshot(
                            body.requestId,
                            ActiveRequestStatus.MANUAL_BROADCAST,
                            reason = body.reason,
                        ).toEntity(requireRequesterId()),
                    )
                    pendingSubmissionDao.delete(requireRequesterId(), draft.id)
                    fallback
                } else {
                    activeRequestDao.upsert(
                        ActiveRequestSnapshot(
                            body.requestId,
                            ActiveRequestStatus.AWAITING_RESPONSES,
                            body.notificationsCreated,
                        ).toEntity(requireRequesterId()),
                    )
                    pendingSubmissionDao.delete(requireRequesterId(), draft.id)
                    SubmitResult.MatchingStarted(
                        body.requestId,
                        body.matches.map { it.toDiscoveredDonor() },
                    )
                }
            }
        } catch (_: IOException) {
            if (networkAvailable()) {
                SubmitResult.Error(
                    "LifeLink is taking longer than expected to respond. Your draft is saved; please retry in a moment.",
                    retryable = true,
                )
            } else {
                queueForRetry(draft)
                SubmitResult.OfflineQueued(draft.id)
            }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            SubmitResult.Error("We couldn’t reach LifeLink right now. Your draft is still saved.")
        }
    }

    override suspend fun sendManualBroadcast(requestId: String): SubmitResult = withContext(Dispatchers.IO) {
        try {
            val response = api.sendManualBroadcast(requestId)
            if (response.isSuccessful) {
                activeRequestDao.upsert(
                    ActiveRequestSnapshot(requestId, ActiveRequestStatus.AWAITING_RESPONSES).toEntity(requireRequesterId()),
                )
                SubmitResult.MatchingStarted(response.body()?.requestId ?: requestId)
            } else {
                SubmitResult.Error("Manual broadcast could not be sent (${response.code()}).")
            }
        } catch (_: IOException) {
            SubmitResult.Error("You’re offline. No manual broadcast was sent.")
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            SubmitResult.Error("Manual broadcast could not be sent. Please retry.")
        }
    }

    override suspend fun contactSelectedDonors(requestId: String, donorIds: List<String>): SubmitResult = withContext(Dispatchers.IO) {
        try {
            val response = api.contactSelectedDonors(requestId, ContactSelectedDonorsRequest(donorIds))
            if (response.isSuccessful) {
                val body = runCatching {
                    response.body()?.string()?.takeIf { it.isNotBlank() }
                        ?.let { Gson().fromJson(it, ContactSelectedDonorsResponse::class.java) }
                }.getOrNull()
                if (body == null) {
                    SubmitResult.ContactRequestUncertain(requestId, donorIds)
                } else {
                    SubmitResult.ContactRequested(body.requestId, body.donorIds)
                }
            } else {
                SubmitResult.Error("Selected donors could not be contacted (${response.code()}).")
            }
        } catch (_: IOException) {
            SubmitResult.Error("You’re offline. No donor contact request was sent.")
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            SubmitResult.Error("Selected donors could not be contacted. Please retry.")
        }
    }

    override suspend fun refreshMatches(requestId: String): List<DiscoveredDonor> = withContext(Dispatchers.IO) {
        val response = api.getEmergencyRequest(requestId)
        if (!response.isSuccessful) throw IOException("Matching results could not be loaded (${response.code()}).")
        val body = response.body() ?: throw IOException("Matching results returned an empty response.")
        body.matches.map { it.toDiscoveredDonor() }
    }

    override suspend fun refreshContacts(requestId: String): List<RequesterContact> = withContext(Dispatchers.IO) {
        val response = api.requesterContacts(requestId)
        if (!response.isSuccessful) throw IOException("Contact activity could not be loaded (${response.code()}).")
        val body = response.body() ?: throw IOException("Contact activity returned an empty response.")
        body.map {
            RequesterContact(it.donorId, it.displayName, it.status, it.acceptedAt, it.contactSharedAt, it.updatedAt, it.contactEmail)
        }
    }

    override suspend fun updateContactStatus(requestId: String, donorId: String, status: String): RequesterContact = withContext(
        Dispatchers.IO,
    ) {
        val response = api.updateContactStatus(requestId, donorId, ContactStatusUpdateRequest(status))
        if (!response.isSuccessful ||
            response.body() == null
        ) {
            throw IOException("Contact status could not be updated (${response.code()}).")
        }
        response.body()!!.let {
            RequesterContact(it.donorId, it.displayName, it.status, it.acceptedAt, it.contactSharedAt, it.updatedAt, it.contactEmail)
        }
    }

    override suspend fun reportContact(requestId: String, donorId: String, reason: String): String = withContext(Dispatchers.IO) {
        val response = api.reportContact(requestId, donorId, ContactModerationRequest(reason))
        if (!response.isSuccessful) throw IOException("Contact could not be reported (${response.code()}).")
        response.body()?.action ?: "reported"
    }

    override suspend fun blockContact(requestId: String, donorId: String): String = withContext(Dispatchers.IO) {
        val response = api.blockContact(requestId, donorId)
        if (!response.isSuccessful) throw IOException("Contact could not be blocked (${response.code()}).")
        response.body()?.action ?: "blocked"
    }

    override suspend fun cancelRequest(requestId: String): SubmitResult = withContext(Dispatchers.IO) {
        try {
            val response = api.cancelEmergencyRequest(requestId)
            if (response.isSuccessful) {
                activeRequestDao.upsert(
                    ActiveRequestSnapshot(
                        requestId = requestId,
                        status = ActiveRequestStatus.CANCELLED,
                        reason = response.body()?.reason ?: "Cancelled by coordinator",
                    ).toEntity(requireRequesterId()),
                )
                SubmitResult.Cancelled(requestId)
            } else {
                SubmitResult.Error("The request could not be cancelled (${response.code()}).")
            }
        } catch (_: IOException) {
            SubmitResult.Error("You’re offline. The request is still active.")
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            SubmitResult.Error("The request could not be cancelled. Please retry.")
        }
    }

    override suspend fun fulfillRequest(requestId: String): SubmitResult = withContext(Dispatchers.IO) {
        try {
            val response = api.fulfillEmergencyRequest(requestId)
            if (response.isSuccessful) {
                activeRequestDao.upsert(
                    ActiveRequestSnapshot(
                        requestId,
                        ActiveRequestStatus.FULFILLED,
                        reason = response.body()?.reason,
                    ).toEntity(requireRequesterId()),
                )
                SubmitResult.Fulfilled(requestId)
            } else {
                SubmitResult.Error("The request could not be marked fulfilled (${response.code()}).")
            }
        } catch (_: IOException) {
            SubmitResult.Error("You’re offline. The request is still active.")
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            SubmitResult.Error("The request could not be marked fulfilled. Please retry.")
        }
    }

    private suspend fun queueForRetry(draft: EmergencyRequestDraft) {
        pendingSubmissionDao.upsert(
            PendingSubmissionEntity(ownerId = requireRequesterId(), id = draft.id, payloadJson = Gson().toJson(draft)),
        )
        val constraints = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        val work = OneTimeWorkRequestBuilder<PendingSubmissionWorker>()
            .setConstraints(constraints)
            .setInputData(
                workDataOf(PendingSubmissionWorker.OWNER_ID to requireRequesterId(), PendingSubmissionWorker.DRAFT_ID to draft.id),
            )
            .addTag("lifelink-account-${requireRequesterId()}")
            .build()
        workManager.enqueueUniqueWork("lifelink-submit-${requireRequesterId()}-${draft.id}", ExistingWorkPolicy.KEEP, work)
    }

    private fun requireRequesterId(): String =
        requesterIdProvider()?.takeIf { it.isNotBlank() } ?: error("Sign in before using emergency requests.")

    private fun serverError(code: Int, body: String?): String {
        val detail = body?.let {
            runCatching { Gson().fromJson(it, ApiErrorResponse::class.java)?.detail }.getOrNull()
        }?.takeIf { it.isNotBlank() }
        return detail ?: when (code) {
            409 -> "This request conflicts with current server data. Refresh and submit again."
            503 -> "LifeLink could not save the request right now. Please retry."
            else -> "The server rejected the request ($code). Check the details and try again."
        }
    }
}

private data class ApiErrorResponse(val detail: String? = null)

class LifeLinkAccountContainer(
    val api: LifeLinkApi,
    val emergencyRequestRepository: EmergencyRequestRepository,
    val donorRepository: DonorRepository,
    val donorProfileRepository: DonorProfileRepository,
    val updatesRepository: UpdatesRepository,
    val privacyRepository: PrivacyRepository,
)

private fun EmergencyRequestDraft.toEntity(ownerId: String) = EmergencyRequestDraftEntity(
    ownerId = ownerId, id = id, bloodType = bloodType?.name, units = units, typeUnknown = typeUnknown,
    urgency = urgency.name, responseDeadline = responseDeadline, note = note,
    facilityId = facility?.id, facilityName = facility?.name, facilityArea = facility?.area,
    facilityVerified = facility?.verified ?: false, contactMethod = contactMethod.name,
    requesterLatitude = requesterLatitude, requesterLongitude = requesterLongitude,
    locationPrecisionMeters = locationPrecisionMeters,
    genuineRequestConfirmed = genuineRequestConfirmed, sharingConsentConfirmed = sharingConsentConfirmed,
    aiMatchingEnabled = aiMatchingEnabled,
    updatedAtEpochMillis = System.currentTimeMillis(),
)

private fun EmergencyRequestDraftEntity.toDomain() = EmergencyRequestDraft(
    id = id,
    bloodType = bloodType?.let {
        runCatching { com.lifelink.app.domain.BloodType.valueOf(it) }.getOrNull()
    },
    units = units, typeUnknown = typeUnknown,
    urgency = enumValueOf<Urgency>(urgency), responseDeadline = responseDeadline, note = note,
    facility = facilityId?.let { Facility(it, facilityName.orEmpty(), facilityArea.orEmpty(), facilityVerified) },
    requesterLatitude = requesterLatitude, requesterLongitude = requesterLongitude,
    locationPrecisionMeters = locationPrecisionMeters,
    contactMethod = enumValueOf<ContactMethod>(contactMethod), genuineRequestConfirmed = genuineRequestConfirmed,
    sharingConsentConfirmed = sharingConsentConfirmed, aiMatchingEnabled = aiMatchingEnabled,
)

private fun com.lifelink.app.data.remote.EmergencyRequestStatusResponse.toSnapshot() = ActiveRequestSnapshot(
    requestId = requestId,
    status = runCatching { ActiveRequestStatus.valueOf(status.uppercase()) }.getOrDefault(ActiveRequestStatus.MATCHING),
    notificationsCreated = notificationsCreated,
    matchesResponded = matchesResponded,
    reason = reason,
)

private fun DonorMatchResponse.toDiscoveredDonor() = DiscoveredDonor(
    donorId = donorId,
    displayName = displayName,
    bloodType = bloodType,
    distanceKm = distanceKm,
    travelMinutes = travelMinutes,
    score = score,
    explanation = explanation?.factors.orEmpty(),
)
