package com.lifelink.app.domain

import kotlinx.coroutines.flow.Flow

enum class DonorAvailability(val label: String) { AVAILABLE("Available"), PAUSED("Paused"), OFFLINE("Offline") }
enum class DonorResponse(val label: String) { ACCEPTED("Accepted"), DECLINED("Declined"), ARRIVED("Arrived") }

data class DonorProfile(
    val donorId: String = "local-donor",
    val displayName: String = "",
    val bloodType: BloodType? = null,
    val area: String = "",
    val serviceRadiusKm: Int = 10,
    val availability: DonorAvailability = DonorAvailability.OFFLINE,
    val verified: Boolean = false,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val locationPrecisionMeters: Int = 500,
    val donorNote: String = "",
    val preferredContactMethod: String = "in_app",
    val pauseReason: String? = null,
    val profileVisible: Boolean = true
) {
    val isSetupComplete: Boolean
        get() = displayName.trim().length >= 2 &&
            bloodType != null &&
            latitude != null &&
            longitude != null &&
            serviceRadiusKm in 1..100
}

data class DonorRequest(
    val requestId: String,
    val bloodType: String,
    val units: Int,
    val urgency: String,
    val facilityName: String,
    val area: String,
    val distanceKm: Double,
    val response: DonorResponse? = null
)

interface DonorRepository {
    fun observeProfile(): Flow<DonorProfile>
    fun observeRequests(): Flow<List<DonorRequest>>
    suspend fun saveProfile(profile: DonorProfile)
    suspend fun setAvailability(availability: DonorAvailability)
    suspend fun refresh()
    suspend fun respond(requestId: String, response: DonorResponse): Result<Unit>
}
