package com.lifelink.app.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "emergency_request_drafts", primaryKeys = ["ownerId", "id"])
data class EmergencyRequestDraftEntity(
    val ownerId: String,
    val id: String,
    val bloodType: String?,
    val units: Int,
    val typeUnknown: Boolean,
    val urgency: String,
    val responseDeadline: String,
    val note: String,
    val facilityId: String?,
    val facilityName: String?,
    val facilityArea: String?,
    val facilityVerified: Boolean,
    val requesterLatitude: Double?,
    val requesterLongitude: Double?,
    val locationPrecisionMeters: Int,
    val contactMethod: String,
    val genuineRequestConfirmed: Boolean,
    val sharingConsentConfirmed: Boolean,
    val aiMatchingEnabled: Boolean,
    val updatedAtEpochMillis: Long
)
